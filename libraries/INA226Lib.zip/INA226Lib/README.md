# INA226Lib

INA226 Bi-directional Current/Power Monitor Arduino Library

## Credits

Original Code by Korneliusz Jarzebski (https://github.com/jarzebski/Arduino-DS1307)
